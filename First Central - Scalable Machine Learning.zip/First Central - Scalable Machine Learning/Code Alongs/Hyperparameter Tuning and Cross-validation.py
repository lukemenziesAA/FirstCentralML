# Databricks notebook source
# MAGIC %md
# MAGIC <div style="text-align: left; line-height: 0; padding-top: 9px; padding-left:150px">
# MAGIC   <img src="https://static1.squarespace.com/static/5bce4071ab1a620db382773e/t/5d266c78abb6d10001e4013e/1562799225083/appliedazuredatabricks3.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>
# MAGIC
# MAGIC # *Hyperparameter tuning and Cross-validation*. Presented by <a href="www.advancinganalytics.co.uk">Advancing Analytics</a>

# COMMAND ----------

# DBTITLE 0,--i18n-2ab084da-06ed-457d-834a-1d19353e5c59
# MAGIC %md 
# MAGIC 💡 In this lesson you will grasp the following concepts:
# MAGIC * Tune hyperparameters using Spark ML’s grid search feature
# MAGIC * Explain cross validation concepts and how to use cross validation in Spark ML pipelines
# MAGIC * Optimise a Spark ML pipeline
# MAGIC

# COMMAND ----------

# DBTITLE 0,--i18n-67393595-40fc-4274-b9ed-40f8ef4f7db1
# MAGIC %md 
# MAGIC
# MAGIC ## Build a Model Pipeline

# COMMAND ----------

readPath = "dbfs:/FileStore/tables/real_estate.csv"

df = (
    (
        #Fill in here
    )
)

label = "Y house price of unit area"


# COMMAND ----------

from pyspark.ml.feature import StringIndexer, VectorAssembler, OneHotEncoder, StandardScaler
from pyspark.ml import Transformer, Pipeline
from pyspark.sql.types import DoubleType, IntegerType
from pyspark.ml.regression import RandomForestRegressor
import re

from pyspark.ml.tuning import ParamGridBuilder
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.tuning import CrossValidator

# COMMAND ----------

# MAGIC %md
# MAGIC ## Split the dataframe into a test and train dataset
# MAGIC The cell below shows the splitting of data into a training and test dataset. This is a vital step when building  a machine learninging model since a model needs to be tested on data it hasn't seen before. Typically the test dataset if smaller than the training dataset (20%-30%). Depending on the type of problem, will determine the way it is split. Below uses a random split where the data is shuffled around (removes ordering).

# COMMAND ----------

seed = 42
#Fill in here

# COMMAND ----------

feats = # Fill in here
vectorAssembler = VectorAssembler(
    inputCols=feats, outputCol="rawFeatures", handleInvalid="skip"
)

model = RandomForestRegressor(featuresCol="rawFeatures", labelCol=label)

stages = [vectorAssembler, model]
pipeline = Pipeline(stages=stages)

# COMMAND ----------

# DBTITLE 0,--i18n-4561938e-90b5-413c-9e25-ef15ba40e99c
# MAGIC %md 
# MAGIC ### ParamGrid
# MAGIC Examining various hyperparameters we could tune for random forest.

# COMMAND ----------

print(model.explainParams())

# COMMAND ----------

# DBTITLE 0,--i18n-819de6f9-75d2-45df-beb1-6b59ecd2cfd2
# MAGIC %md 
# MAGIC Considering the following two
# MAGIC   - **`maxDepth`**: max depth of each decision tree (Use the values **`2, 5`**)
# MAGIC   - **`numTrees`**: number of decision trees to train (Use the values **`5, 10`**)
# MAGIC
# MAGIC **`addGrid()`** accepts the name of the parameter (e.g. **`rf.maxDepth`**), and a list of the possible values (e.g. **`[2, 5]`**).

# COMMAND ----------

param_grid = (
      #Fill in here
)

# COMMAND ----------

# DBTITLE 0,--i18n-9f043287-11b8-482d-8501-2f7d8b1458ea
# MAGIC %md 
# MAGIC
# MAGIC
# MAGIC
# MAGIC ## Cross Validation
# MAGIC
# MAGIC We are also going to use 3-fold cross validation to identify the optimal hyperparameters.
# MAGIC
# MAGIC ![crossValidation](https://files.training.databricks.com/images/301/CrossValidation.png)
# MAGIC
# MAGIC With 3-fold cross-validation, we train on 2/3 of the data, and evaluate with the remaining (held-out) 1/3. We repeat this process 3 times, so each fold gets the chance to act as the validation set. We then average the results of the three rounds.

# COMMAND ----------

evaluator = RegressionEvaluator(
    labelCol=label, predictionCol="prediction", metricName="rmse"
)

cv = CrossValidator(
    #Fill in here
)

# COMMAND ----------

# MAGIC %md
# MAGIC Perform cross-validation accross parameter range

# COMMAND ----------

cv_model = #Fill in here

# COMMAND ----------

# DBTITLE 0,--i18n-2d00b40f-c5e7-4089-890b-a50ccced34c6
# MAGIC %md 
# MAGIC
# MAGIC
# MAGIC
# MAGIC **Question**: Should we put the pipeline in the cross validator, or the cross validator in the pipeline?
# MAGIC
# MAGIC It depends if there are estimators or transformers in the pipeline. If you have things like StringIndexer (an estimator) in the pipeline, then you have to refit it every time if you put the entire pipeline in the cross validator.
# MAGIC
# MAGIC However, if there is any concern about data leakage from the earlier steps, the safest thing is to put the pipeline inside the CV, not the other way. CV first splits the data and then .fit() the pipeline. If it is placed at the end of the pipeline, we potentially can leak the info from hold-out set to train set.

# COMMAND ----------

cv = CrossValidator(
        #Fill in here
)

stages_with_cv = #Fill in here
pipeline = Pipeline(stages=stages_with_cv)

pipeline_model = #Fill in here

# COMMAND ----------

# DBTITLE 0,--i18n-42652818-f185-45d2-8e96-8204292fea5b
# MAGIC %md
# MAGIC In the current method, only **one MLflow run is logged**, whereas in the previous method, **five runs** were logged. This is because, in the first method, the pipeline was placed within the CrossValidator, which automatically logs all runs. However, in the second method, since **the pipeline only returns the best model without evaluating metrics**, only that single model is seen. Additionally, no evaluation metrics are logged. Essentially, the Pipeline logs all stages and directly returns the best model without performing model evaluations.

# COMMAND ----------

# DBTITLE 0,--i18n-dede990c-2551-4c07-8aad-d697ae827e71
# MAGIC %md 
# MAGIC Examine the best hyperparameter configuration

# COMMAND ----------

list(zip(cv_model.getEstimatorParamMaps(), cv_model.avgMetrics))

# COMMAND ----------

pred_df = pipeline_model.transform(testDF)

rmse = evaluator.evaluate(pred_df)
r2 = evaluator.setMetricName("r2").evaluate(pred_df)
print(f"RMSE is {rmse}")
print(f"R2 is {r2}")