# Databricks notebook source
# MAGIC %md
# MAGIC <div style="text-align: left; line-height: 0; padding-top: 9px; padding-left:150px">
# MAGIC   <img src="https://static1.squarespace.com/static/5bce4071ab1a620db382773e/t/5d266c78abb6d10001e4013e/1562799225083/appliedazuredatabricks3.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>
# MAGIC
# MAGIC # *Custom Transformer*. Presented by <a href="www.advancinganalytics.co.uk">Advancing Analytics</a>

# COMMAND ----------

# MAGIC %md
# MAGIC 💡 In this lesson you will grasp the following concepts:
# MAGIC * How to create a custom transformer for a machine learning pipeline

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import routines for building up the model

# COMMAND ----------

from pyspark.sql.functions import log, col
from pyspark.sql.functions import regexp_replace, split, col, when
from pyspark.ml.feature import StringIndexer, VectorAssembler, OneHotEncoder, StandardScaler
from pyspark.ml import Transformer, Pipeline
from pyspark.sql.types import DoubleType, IntegerType
from pyspark.ml.classification import GBTClassifier
import re

# COMMAND ----------

# DBTITLE 0,--i18n-3e08ca45-9a00-4c6a-ac38-169c7e87d9e4
# MAGIC %md
# MAGIC ## Loading in the data
# MAGIC Below is the command for reading in a csv file into a Spark Dataframe that can be used passed to a model. The dataframe can be displayed using 'display(df)'. Or it can be converted to a Pandas Dataframe and displayed by typeing 'df' into a cell.

# COMMAND ----------

readPath = "dbfs:/FileStore/tables/credit_card_churn.csv"

drop_cols = [
    "CLIENTNUM",
    "Naive_Bayes_Classifier_Attrition_Flag_Card_Category_Contacts_Count_12_mon_Dependent_count_Education_Level_Months_Inactive_12_mon_1",
    "Naive_Bayes_Classifier_Attrition_Flag_Card_Category_Contacts_Count_12_mon_Dependent_count_Education_Level_Months_Inactive_12_mon_2",
]

df = (
    spark.read.option("header", True)
    .format("csv")
    .option("inferSchema", True)
    .load(readPath)
).drop(*drop_cols)

target_col = "Attrition_Flag"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Split the dataframe into a test and train dataset
# MAGIC The cell below shows the splitting of data into a training and test dataset. This is a vital step when building  a machine learninging model since a model needs to be tested on data it hasn't seen before. Typically the test dataset if smaller than the training dataset (20%-30%). Depending on the type of problem, will determine the way it is split. Below uses a random split where the data is shuffled around (removes ordering).

# COMMAND ----------

seed = 42
trainDF, testDF = df.randomSplit([0.7, 0.3], seed=seed)

print(
    "We have %d training examples and %d test examples."
    % (trainDF.count(), testDF.count())
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Created Custom Transformer
# MAGIC This is a custom transformer that imports and inherets 'Transformer' into the class. It can be used for machine learning transformation, and passed into machine learning pipelines. It receives a PySpark DataFrame requires manipulation of using PySpark.

# COMMAND ----------

df.display()

# COMMAND ----------

class GetAverageSalary(Transformer):
    """
    A custom Spark Transformer that estimates the average salary from an income category column in a DataFrame.
    
    The income category column typically contains ranges in a string format (e.g., "$40K - $60K").
    This transformer processes the column to extract numeric values, computes the average of these values,
    and adds a new column to the DataFrame with the estimated average salary.
    
    Attributes:
        c (str): The name of the column containing the income category ranges.
        
    Methods:
        __init__(self, c="Income_Category"): Constructor for the GetAverageSalary class.
        _transform(self, df): Transforms the input DataFrame by adding an 'average_salary' column.
    """
    
    def __init__(self, c="Income_Category"):
        """
        Initializes the GetAverageSalary transformer with the specified income category column.
        
        Parameters:
            c (str): The name of the column to process. Defaults to "Income_Category".
        """
        super().__init__()
        self.c = c
        
    def _transform(self, df):
        """
        Transforms the input DataFrame by estimating the average salary from the income category column.
        
        The method cleans the income category column to remove non-numeric characters, splits the range,
        fills null values, and computes the average of the range to estimate the average salary.
        It then adds this estimated average salary as a new column to the DataFrame.
        
        Parameters:
            df (DataFrame): The input DataFrame to transform.
            
        Returns:
            DataFrame: The transformed DataFrame with an added 'average_salary' column.
        """
        # Remove non-numeric characters and split the range into two parts
        df = df.withColumn("cleaned_column", regexp_replace(self.c, "[^0-9-]", ""))
        df = df.withColumn(
            "first_digit", split(df["cleaned_column"], "-").getItem(0)
        ).withColumn("second_digit", split(df["cleaned_column"], "-").getItem(1))

        # Fill null values in 'first_digit' and 'second_digit' with the non-null counterpart
        df = df.withColumn(
            "first_digit",
            when(col("first_digit").isNull(), col("second_digit")).otherwise(
                col("first_digit")
            ),
        )
        df = df.withColumn(
            "second_digit",
            when(col("second_digit").isNull(), col("first_digit")).otherwise(
                col("second_digit")
            ),
        )

        # Calculate the average of the two digits and add it as 'average_salary'
        df = df.withColumn(
            "average_salary",
            (col("second_digit").cast("double") + col("first_digit").cast("double")) / 2,
        )
        # Drop intermediate columns
        df = df.drop("cleaned_column", "first_digit", "second_digit")
        return df

# COMMAND ----------

avsal = GetAverageSalary()
display(avsal.transform(df))

# COMMAND ----------

cat_feats = [
    "Gender",
    "Education_Level",
    "Marital_Status",
    "Income_Category",
    "Card_Category",
]
num_feats = list(
    map(
        lambda y: y.name,
        filter(
            lambda x: isinstance(x.dataType, IntegerType)
            or isinstance(x.dataType, DoubleType),
            df.schema,
        ),
    )
)

out_cats = [i + "_catv" for i in cat_feats]
f_cats = [i + "_cat" for i in cat_feats]
vec_feats = num_feats + out_cats

stringIndexer = StringIndexer(
    inputCols=cat_feats + [target_col], outputCols=out_cats + [f"{target_col}_num"]
)

vectorAssembler = VectorAssembler(
    inputCols=vec_feats, outputCol="rawFeatures", handleInvalid="skip"
)
ohe = OneHotEncoder(inputCols=out_cats, outputCols=f_cats)

params = {
    "n_estimators": 100,
    "learning_rate": 0.1,
    "max_depth": 4,
    "random_state": 42,
    "missing": 0,
}

gbt_model = GBTClassifier(featuresCol="rawFeatures", labelCol=f"{target_col}_num")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create pipeline with transformer
# MAGIC Create pipeline with custom transformer in the pipeline stages.

# COMMAND ----------

model = Pipeline().setStages([avsal, stringIndexer, vectorAssembler, gbt_model])

# COMMAND ----------

pipeline_model = model.fit(trainDF)
predictionDF = pipeline_model.transform(testDF)

# COMMAND ----------

# DBTITLE 0,--i18n-8d5f8c24-ee0b-476e-a250-95ce2d73dd28
# MAGIC %md
# MAGIC ## Scoring the model
# MAGIC The cell below shows how the use can score the model. A couple of metrics are shown below. More information on scoring metrics will be given in another part of the course. 

# COMMAND ----------

from pyspark.ml.evaluation import MulticlassClassificationEvaluator

evaluatorf1 = (
    MulticlassClassificationEvaluator()
    .setMetricName("f1")
    .setPredictionCol("prediction")
    .setLabelCol(f"{target_col}_num")
)
evaluatorac = (
    MulticlassClassificationEvaluator()
    .setMetricName("accuracy")
    .setPredictionCol("prediction")
    .setLabelCol(f"{target_col}_num")
)

f1 = evaluatorf1.evaluate(predictionDF)
ac = evaluatorac.evaluate(predictionDF)
print("F1 = %f" % f1)
print("Accuracy = %f" % ac)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create Custom Transformer (utilising UDFs)
# MAGIC This is a custom transformer that utilises a UDF. Simplifying the code through using regular Python syntax as opposed to PySpark.

# COMMAND ----------

class GetAverageSalary(Transformer):
    """
    A custom Spark Transformer that calculates the average salary based on a specified income category column.
    It cleans the column by removing non-numeric characters, splits the range into two numbers,
    handles null values, and computes the average of these numbers to estimate the average salary.
    """
    
    def __init__(self, c="Income_Category"):
        """
        Initializes the transformer with a specific column name.
        
        :param c: The name of the column to process. Defaults to "Income_Category".
        """
        super().__init__()
        self.c = c
        
    def _transform(self, df):
        """
        The transformation logic for the DataFrame.
        
        :param df: The input DataFrame to transform.
        :return: DataFrame with an additional column "average_salary" representing the estimated average salary.
        """
        def get_avg(x):
            """
            Helper function to calculate the average salary from a salary range string.
            
            :param x: A string representing a salary range (e.g., "$40K-$50K").
            :return: The average salary as a float.
            """
            # Remove non-numeric characters, split by '-', and convert to float. Replace missing values with 0.
            out = list(map(lambda c: 0 if c == '' else float(c), re.sub("[^0-9-]", "", x).split('-')))
            # If only one number is present, assume it as both start and end of the range.
            if len(out) == 1:
                out = [out[0]*2]
            # Calculate the average of the range.
            return sum(out)*0.5

        # Define a UDF to apply the get_avg function on Spark DataFrame columns.
        avgc = udf(get_avg, DoubleType())
        # Apply the UDF to the specified column and add the result as a new column.
        return df.withColumn("average_salary", avgc(df[self.c]))

# COMMAND ----------

model = Pipeline().setStages([GetAverageSalary(), stringIndexer, vectorAssembler, gbt_model])
pipeline_model = model.fit(trainDF)
predictionDF = pipeline_model.transform(testDF)
f1 = evaluatorf1.evaluate(predictionDF)
ac = evaluatorac.evaluate(predictionDF)
print("F1 = %f" % f1)
print("Accuracy = %f" % ac)

# COMMAND ----------

