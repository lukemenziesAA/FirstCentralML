# Databricks notebook source
# MAGIC %md
# MAGIC <div style="text-align: left; line-height: 0; padding-top: 9px; padding-left:150px">
# MAGIC   <img src="https://static1.squarespace.com/static/5bce4071ab1a620db382773e/t/5d266c78abb6d10001e4013e/1562799225083/appliedazuredatabricks3.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>
# MAGIC
# MAGIC # *Crime and Taxis Demo*. Presented by <a href="www.advancinganalytics.co.uk">Advancing Analytics</a>

# COMMAND ----------

# MAGIC %md 
# MAGIC 💡 In this lesson you will grasp the following concepts:
# MAGIC * Setting up Mosaic
# MAGIC * Converting WkT or WkB to Mosaic index
# MAGIC * Converting Polygon to Mosaic tiling
# MAGIC * Optimising join for working out what points lie inside Polygons
# MAGIC * Displaying results using Kepler

# COMMAND ----------

# MAGIC %md
# MAGIC ### Installing Mosaic
# MAGIC This can be done in the 'Libraries' tab when setting up a cluster. 

# COMMAND ----------

# MAGIC %pip install databricks-mosaic

# COMMAND ----------

# MAGIC %md
# MAGIC ### Enable Mosaic
# MAGIC The command below has to be run, in order for Mosaic to work correctly

# COMMAND ----------

import os
import mosaic as mos

mos.enable_mosaic(spark, dbutils)

# COMMAND ----------

# MAGIC %md
# MAGIC Import PySpark routines

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ### Read in crime dataset

# COMMAND ----------

crimeDF = (
    spark.read.format("csv")
    .option("header", True)
    .load("dbfs:/FileStore/tables/nypp.csv")
    .withColumn("geometry", mos.st_geomfromwkt("the_geom"))
    .withColumn("mosaic_index", mos.grid_tessellateexplode(col("geometry"), lit(8)))
    .drop("the_geom")
)

# COMMAND ----------

display(crimeDF)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Display polygons

# COMMAND ----------

# MAGIC %%mosaic_kepler
# MAGIC crimeDF.groupBy('geometry').count() "geometry" "geometry" 1000

# COMMAND ----------

# MAGIC %sql
# MAGIC Create DATABASE if not exists taxi_data

# COMMAND ----------

not_loaded = False

# COMMAND ----------

if not_loaded:
    df_yellow = (
        spark.read.format("csv")
        .option("header", "true")
        .option("compression", "gzip")
        .load(
            "dbfs:/databricks-datasets/nyctaxi/tripdata/yellow/yellow_tripdata_*.csv.gz"
        )
    )

    df_yellow_silver = (
        df_yellow.withColumnRenamed("vendor_name", "vendor_id")
        .withColumn(
            "pickup_datetime", from_unixtime(unix_timestamp(col("pickup_datetime")))
        )
        .withColumn(
            "dropoff_datetime", from_unixtime(unix_timestamp(col("dropoff_datetime")))
        )
        .withColumnRenamed("store_and_fwd_flag", "store_and_forward")
        .withColumnRenamed("rate_code", "rate_code_id")
        .withColumn("dropoff_latitude", col("dropoff_latitude").cast(DoubleType()))
        .withColumn("dropoff_longitude", col("dropoff_longitude").cast(DoubleType()))
        .withColumn("pickup_latitude", col("pickup_latitude").cast(DoubleType()))
        .withColumn("pickup_longitude", col("pickup_longitude").cast(DoubleType()))
        .withColumn("passener_count", col("Passenger_Count").cast(IntegerType()))
        .withColumn("trip_distance", col("trip_distance").cast(DoubleType()))
        .withColumn("fare_amount", col("fare_amount").cast(DoubleType()))
        .withColumn("extra", col("surcharge").cast(DoubleType()))
        .withColumn("mta_tax", col("mta_tax").cast(DoubleType()))
        .withColumn("tip_amount", col("tip_amount").cast(DoubleType()))
        .withColumn("tolls_amount", col("tolls_amount").cast(DoubleType()))
        .withColumn("total_amount", col("total_amount").cast(DoubleType()))
        .withColumn("payment_type", col("Payment_Type"))
        .withColumn("pickup_year", year("pickup_datetime"))
        .select(
            [
                "vendor_id",
                "pickup_year",
                "pickup_datetime",
                "dropoff_datetime",
                "store_and_forward",
                "rate_code_id",
                "pickup_longitude",
                "pickup_latitude",
                "dropoff_longitude",
                "dropoff_latitude",
                "passener_count",
                "trip_distance",
                "fare_amount",
                "extra",
                "mta_tax",
                "tip_amount",
                "tolls_amount",
                "total_amount",
                "payment_type",
            ]
        )
    )

    df_yellow_silver.write.mode("overwrite").partitionBy(["pickup_year"]).saveAsTable(
        "taxi_data.yellow_taxi"
    )

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE taxi_data.yellow_taxi

# COMMAND ----------

# MAGIC %md
# MAGIC ### Load in taxi data

# COMMAND ----------

taxis = spark.sql(
    'SELECT * FROM taxi_data.yellow_taxi WHERE pickup_datetime >="2016-01-01" AND pickup_datetime <="2016-01-08"'
)

taxis.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Add a unique index to each point

# COMMAND ----------

taxis = taxis.withColumn(
    "index", row_number().over(Window.orderBy(monotonically_increasing_id())) - 1
)

# COMMAND ----------

pnts = (
    taxis.withColumn(
        "points",
        mos.grid_longlatascellid("pickup_longitude", "pickup_latitude", lit(8)),
    )
    .withColumn(
        "geom",
        mos.st_astext(mos.st_point(col("pickup_longitude"), col("pickup_latitude"))),
    )
    .withColumnRenamed("pickup_longitude", "longitude")
    .withColumnRenamed("pickup_latitude", "latitude")
    .select("points", "longitude", "latitude", "geom")
).union(
    (
        taxis.withColumn(
            "points",
            mos.grid_longlatascellid("dropoff_longitude", "dropoff_latitude", lit(8)),
        )
        .withColumn(
            "geom",
            mos.st_astext(
                mos.st_point(col("dropoff_longitude"), col("dropoff_latitude"))
            ),
        )
        .withColumnRenamed("dropoff_longitude", "longitude")
        .withColumnRenamed("dropoff_latitude", "latitude")
        .select("points", "longitude", "latitude", "geom")
    )
)

# COMMAND ----------

taxi_dens = (
    pnts.groupBy("points")
    .agg({"geom": "count"})
    .withColumnRenamed("count(geom)", "density")
)

# COMMAND ----------

display(pnts)

# COMMAND ----------

# MAGIC %%mosaic_kepler
# MAGIC taxi_dens "points" "h3" 10000

# COMMAND ----------

pnts_and_regions = (
    pnts.join(crimeDF, crimeDF["mosaic_index.index_id"] == pnts["points"], how="left")
    .where(
        col("mosaic_index.is_core")
        | mos.st_contains(col("mosaic_index.wkb"), col("geom"))
    )
    .withColumn("wkb", col("mosaic_index.wkb"))
    .select("wkb", "Precinct", "geom")
    .groupBy("wkb", "Precinct")
    .agg({"geom": "count"})
    .withColumnRenamed("count(geom)", "density")
).cache()

# COMMAND ----------

pnts_and_regions.display()

# COMMAND ----------

# MAGIC %%mosaic_kepler
# MAGIC pnts_and_regions "wkb" "geometry" 100000

# COMMAND ----------

