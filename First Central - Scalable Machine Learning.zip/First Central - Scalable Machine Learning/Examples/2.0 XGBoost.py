# Databricks notebook source
# MAGIC %md
# MAGIC <div style="text-align: left; line-height: 0; padding-top: 9px; padding-left:150px">
# MAGIC   <img src="https://static1.squarespace.com/static/5bce4071ab1a620db382773e/t/5d266c78abb6d10001e4013e/1562799225083/appliedazuredatabricks3.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>
# MAGIC
# MAGIC # *XGBoost*. Presented by <a href="www.advancinganalytics.co.uk">Advancing Analytics</a>

# COMMAND ----------

# MAGIC %md
# MAGIC 💡 In this lesson you will grasp the following concepts:
# MAGIC * How to use XGBoost with the Spark Cluster

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import routines for building up the model

# COMMAND ----------

from pyspark.sql.functions import log, col
from pyspark.ml.feature import StringIndexer, VectorAssembler, OneHotEncoder, StandardScaler
from pyspark.ml.classification import GBTClassifier
from pyspark.sql.types import DoubleType, IntegerType
from xgboost.spark import SparkXGBClassifier
from pyspark.ml import Pipeline

# COMMAND ----------

# DBTITLE 0,--i18n-3e08ca45-9a00-4c6a-ac38-169c7e87d9e4
# MAGIC %md
# MAGIC ## Loading in the data
# MAGIC Below is the command for reading in a csv file into a Spark Dataframe that can be used passed to a model. The dataframe can be displayed using 'display(df)'. Or it can be converted to a Pandas Dataframe and displayed by typeing 'df' into a cell.

# COMMAND ----------

readPath = "dbfs:/FileStore/tables/credit_card_churn.csv"

drop_cols = [
    "CLIENTNUM",
    "Naive_Bayes_Classifier_Attrition_Flag_Card_Category_Contacts_Count_12_mon_Dependent_count_Education_Level_Months_Inactive_12_mon_1",
    "Naive_Bayes_Classifier_Attrition_Flag_Card_Category_Contacts_Count_12_mon_Dependent_count_Education_Level_Months_Inactive_12_mon_2",
]

df = (
    spark.read.option("header", True)
    .format("csv")
    .option("inferSchema", True)
    .load(readPath)
).drop(*drop_cols)

target_col = "Attrition_Flag"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Split the dataframe into a test and train dataset
# MAGIC The cell below shows the splitting of data into a training and test dataset. This is a vital step when building  a machine learninging model since a model needs to be tested on data it hasn't seen before. Typically the test dataset if smaller than the training dataset (20%-30%). Depending on the type of problem, will determine the way it is split. Below uses a random split where the data is shuffled around (removes ordering).

# COMMAND ----------

seed = 42
trainDF, testDF = df.randomSplit([0.7, 0.3], seed=seed)

print(
    "We have %d training examples and %d test examples."
    % (trainDF.count(), testDF.count())
)

# COMMAND ----------

# DBTITLE 0,--i18n-733cd880-143d-42c2-9f29-602e48f60efe
# MAGIC %md 
# MAGIC ### Distributed Training of XGBoost Models
# MAGIC To use the distributed version of XGBoost's PySpark estimators, you can specify two additional parameters:
# MAGIC
# MAGIC * **`num_workers`**: The number of workers to distribute over.
# MAGIC * **`use_gpu`**: Enable to utilize GPU based training for faster performance.
# MAGIC
# MAGIC For more information about these parameters and performance considerations, please check this <a href="https://docs.databricks.com/en/machine-learning/train-model/xgboost-spark.html" target="_blank">documentation page.</a>

# COMMAND ----------

cat_feats = [
    "Gender",
    "Education_Level",
    "Marital_Status",
    "Income_Category",
    "Card_Category",
]
num_feats = list(
    map(
        lambda y: y.name,
        filter(
            lambda x: isinstance(x.dataType, IntegerType)
            or isinstance(x.dataType, DoubleType),
            df.schema,
        ),
    )
)

out_cats = [i + "_catv" for i in cat_feats]
f_cats = [i + "_cat" for i in cat_feats]
vec_feats = num_feats + out_cats

stringIndexer = StringIndexer(
    inputCols=cat_feats + [target_col], outputCols=out_cats + [f"{target_col}_num"]
)

vectorAssembler = VectorAssembler(
    inputCols=vec_feats, outputCol="rawFeatures", handleInvalid="skip"
)
ohe = OneHotEncoder(inputCols=out_cats, outputCols=f_cats)

params = {
    "n_estimators": 100,
    "learning_rate": 0.1,
    "max_depth": 4,
    "random_state": 42,
    "missing": 0,
}

xgboost = SparkXGBClassifier(
    features_col="rawFeatures", label_col=f"{target_col}_num", **params
)

gbt_model = GBTClassifier(featuresCol="rawFeatures", labelCol=f"{target_col}_num")

# COMMAND ----------

list(map(lambda x: x.name , xgboost.params))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create predictions for both pipelines
# MAGIC Training below gives predictions for two models. One being the XGBoost model, the other being PySparks GBT model for comparison.

# COMMAND ----------

pipeline_xgb = Pipeline().setStages([stringIndexer, vectorAssembler, xgboost])
pipeline_gbt = Pipeline().setStages([stringIndexer, vectorAssembler, gbt_model])

# COMMAND ----------

pipeline_model = pipeline_xgb.fit(trainDF)
predictionDF = pipeline_model.transform(testDF)

pipeline_model = pipeline_gbt.fit(trainDF)
predictionDFc = pipeline_model.transform(testDF)

# COMMAND ----------

# DBTITLE 0,--i18n-8d5f8c24-ee0b-476e-a250-95ce2d73dd28
# MAGIC %md
# MAGIC ## Scoring the model
# MAGIC The cell below shows how the use can score the model. A couple of metrics are shown below. More information on scoring metrics will be given in another part of the course. 

# COMMAND ----------

from pyspark.ml.evaluation import MulticlassClassificationEvaluator

evaluatorf1 = (
    MulticlassClassificationEvaluator()
    .setMetricName("f1")
    .setPredictionCol("prediction")
    .setLabelCol(f"{target_col}_num")
)
evaluatorac = (
    MulticlassClassificationEvaluator()
    .setMetricName("accuracy")
    .setPredictionCol("prediction")
    .setLabelCol(f"{target_col}_num")
)

f1 = evaluatorf1.evaluate(predictionDF)
ac = evaluatorac.evaluate(predictionDF)
print("XGBoost Test F1 = %f" % f1)
print("XGBoost Test Accuracy = %f" % ac)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Comparing the model
# MAGIC Here we compare the score with the GBT model

# COMMAND ----------

f1 = evaluatorf1.evaluate(predictionDFc)
ac = evaluatorac.evaluate(predictionDFc)
print("GBT Test F1 = %f" % f1)
print("GBT Test Accuracy = %f" % ac)

# COMMAND ----------

