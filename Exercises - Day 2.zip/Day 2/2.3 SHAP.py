# Databricks notebook source
# MAGIC %md
# MAGIC <div style="text-align: left; line-height: 0; padding-top: 9px; padding-left:150px">
# MAGIC   <img src="https://static1.squarespace.com/static/5bce4071ab1a620db382773e/t/5d266c78abb6d10001e4013e/1562799225083/appliedazuredatabricks3.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>
# MAGIC
# MAGIC # *SHAP*. Presented by <a href="www.advancinganalytics.co.uk">Advancing Analytics</a>

# COMMAND ----------

# MAGIC %md
# MAGIC ## Loading in the data
# MAGIC Below is the command for reading in a csv file into a Spark Dataframe that can be used passed to a model. The dataframe can be displayed using 'display(df)'. Or it can be converted to a Pandas Dataframe and displayed by typeing 'df' into a cell.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 1 
# MAGIC Load in dataset. Pick a dataset to use or choose one that is provided

# COMMAND ----------

#Fill in here

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Split the dataframe into a test and train dataset

# COMMAND ----------

#Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import libraries

# COMMAND ----------

#Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 2
# MAGIC Setup Pyspark Desicion Tree model with the dataset and train the model

# COMMAND ----------

# MAGIC %md
# MAGIC ## Setting up the pipeline, training and predicting

# COMMAND ----------

#Fill in here

# COMMAND ----------

pmodel = pipeline.fit(trainDF)
predictionDF = pmodel.transform(testDF)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 3
# MAGIC Evaluate model and print metrics

# COMMAND ----------

# MAGIC %md
# MAGIC ## Scoring the model

# COMMAND ----------

#Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ## Use SHAP
# MAGIC Below is where we explore using SHAP values to explain the model. It should be noted that the data passed to SHAP cannot be as a PySpark dataframe. It has to be as a Pandas dataframe. We therefore have to convert it to the appropriate format for SHAP. This is done below. 

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Libraries

# COMMAND ----------

#Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC The cell below converts the dataframe into the appropriate format and then converts it into a Pandas dataframe. Because PySpark categorical data is in vectorised form, it needs each element of the vector taken out and put into a separate column. The vector_to_array command can be used to do this. 

# COMMAND ----------

df_pandas = (
    input_df.select(
        num_feats
        + [
            vector_to_array(j + "_cat")[i].alias("{}_{}".format(j, i))
            for j in cat_feats
            for i in range(
                input_df.select(size(vector_to_array(j + "_cat"))).collect()[0][0]
            )
        ]
    )
).toPandas()

# COMMAND ----------

display(df_pandas)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 4
# MAGIC Create Tree explainer and summary plot from model

# COMMAND ----------

#Train the model
rfc = #Fill in here
explainer = shap.TreeExplainer(rfc)
shap_values = explainer.shap_values(#Fill in here, check_additivity=False)

# COMMAND ----------

p = shap.summary_plot(shap_values[0], df_pandas, show=False)
display(p)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 5
# MAGIC Repeat the same but using a scikit-learn model. It is recommeneded to use a tree based model, however the Kernel Explainer can be used for other model types (it does take longer to create).

# COMMAND ----------

# MAGIC %md
# MAGIC ## Scikit-learn and SHAP
# MAGIC Below we shall use the Scikit-learn library to craete a model. We can then compare the SHAP values using the PySpark model above with the Scikit-learn model below. You will notice that they're very similar in output. 

# COMMAND ----------

# Train a model
#Fill in here. Hint, no need to use a pipeline because the data is already transformed for df_pandas

# COMMAND ----------

#Fill in here

# COMMAND ----------

#Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 6
# MAGIC Use PySparks distributed computing capabilities to speed up the process of computing SHAP values. The function has been provided. Use with mapInPandas

# COMMAND ----------

# MAGIC %md
# MAGIC ## Using a UDF to create SHAP values
# MAGIC Generating SHAP values can be very computationally intensive. You can ustilise Sparks capabilities to speed up the process of generating SHAP values. Below is the code used to do it. 

# COMMAND ----------

explainer = #Fill in here
columns_for_shap_calculation = #Fill in here

def calculate_shap(iterator: Iterator[pd.DataFrame]) -> Iterator[pd.DataFrame]:
    for X in iterator:
        yield pd.DataFrame(
            explainer.shap_values(np.array(X), check_additivity=False)[0],
            columns=columns_for_shap_calculation,
        )


return_schema = #Fill in here

shap_values = (
    #Fill in here
)

# COMMAND ----------

# MAGIC %md
# MAGIC Here you can see the displayed result is the same as the previous results that didn't use the UDF to speed up the process. 

# COMMAND ----------

p = #Fill in here
display(p)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 7
# MAGIC Create individual force plots for rows of data. Use any row you want. 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Displaying individual shap entries
# MAGIC Below displays how to use SHAP on individual predicted entries. 

# COMMAND ----------

shap_display = #Fill in here
)
display(shap_display)