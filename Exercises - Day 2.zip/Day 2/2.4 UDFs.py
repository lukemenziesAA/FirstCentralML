# Databricks notebook source
# MAGIC %md
# MAGIC <div style="text-align: left; line-height: 0; padding-top: 9px; padding-left:150px">
# MAGIC   <img src="https://static1.squarespace.com/static/5bce4071ab1a620db382773e/t/5d266c78abb6d10001e4013e/1562799225083/appliedazuredatabricks3.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>
# MAGIC
# MAGIC # *Pandas UDF for Training and Scoring*. Presented by <a href="www.advancinganalytics.co.uk">Advancing Analytics</a>

# COMMAND ----------

# MAGIC %md 
# MAGIC 💡 In this lesson you will grasp the following concepts:
# MAGIC * Use apply in Pandas for Training
# MAGIC * Use apply in Pandas for Scoring

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 1 
# MAGIC Load in libraries and pick a dataset to use.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Installing Libraries
# MAGIC

# COMMAND ----------

#Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ## Loading in the data
# MAGIC Below is the command for reading in a parquet file into a Spark Dataframe that can be used passed to a model. The dataframe can be displayed using 'display(df)'. Or it can be converted to a Pandas Dataframe and displayed by typeing 'df' into a cell.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 2
# MAGIC Load in the data and create partition key for train and individual model on (if there isn't one already)

# COMMAND ----------

data = (
    #Fill in here
)

# COMMAND ----------

data.display()

# COMMAND ----------

label = #Fill in here

# COMMAND ----------

import mlflow

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 3
# MAGIC Create and experiment and set one if it already exists.

# COMMAND ----------

# MAGIC %md
# MAGIC ###Set Experiment
# MAGIC Create and experiment to centralise the runs. If the experiment already exists, set the extisting one. 

# COMMAND ----------

#Fill in here

# COMMAND ----------

model = #Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 4
# MAGIC Create training function to train models on partition and return run id and partition id.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Training Function
# MAGIC Create a training routine that trains a model and returns the run_id, along with the partition key. This partitiion key is what the dataset is grouped on, such that there's a model for each partition. Ensuring that a Pandas DataFrame is returned

# COMMAND ----------

#Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create output schema
# MAGIC Create the output schema that returns the run_id and the partition key

# COMMAND ----------

schema = #Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 5
# MAGIC Perform groupby and output results.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Perform groupby
# MAGIC Perform groupby on the partition key to train each partition

# COMMAND ----------

out_df = #Fill in here

# COMMAND ----------

out_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 6 
# MAGIC Score without a groupby but using a UDF and MLFlow

# COMMAND ----------

# MAGIC %md
# MAGIC ### Scoring with UDFs
# MAGIC You can also score with UDFs directly using MLflow thorugh the spark_udf functionality. This is only available with PyFunc models. 

# COMMAND ----------

#Fill in here

# COMMAND ----------

data_with_mod = #Fill in here

# COMMAND ----------

display(data_with_mod)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 7 
# MAGIC Create scoring function that score teh data based on partition.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Scoring using Pandas UDFs
# MAGIC Once all the models have been trained, the following routine below can be used to score on another dataset. Passing the run id to the appropriate partition allows the use of MLflow to load the model in and score on the data. The data is then returned as a Pandas DataFrame. 

# COMMAND ----------

#Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 8
# MAGIC Perform groupby and output the scored results.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Scoring using groupby
# MAGIC Use the groupby and applyInPandas, passing the function through to score the data. 

# COMMAND ----------

final_out = data_with_mod #Fill in here

# COMMAND ----------

final_out.display()