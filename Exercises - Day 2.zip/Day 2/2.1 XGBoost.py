# Databricks notebook source
# MAGIC %md
# MAGIC <div style="text-align: left; line-height: 0; padding-top: 9px; padding-left:150px">
# MAGIC   <img src="https://static1.squarespace.com/static/5bce4071ab1a620db382773e/t/5d266c78abb6d10001e4013e/1562799225083/appliedazuredatabricks3.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>
# MAGIC
# MAGIC # *XGBoost*. Presented by <a href="www.advancinganalytics.co.uk">Advancing Analytics</a>

# COMMAND ----------

# MAGIC %md
# MAGIC 💡 In this lesson you will grasp the following concepts:
# MAGIC * How to use XGBoost with the Spark Cluster
# MAGIC * Compare with another model

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import routines for building up the model

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 1
# MAGIC Load in the libraries needed. 

# COMMAND ----------

#Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 2
# MAGIC Load in the dataset. Either pick one provided or use your own. 

# COMMAND ----------

# DBTITLE 0,--i18n-3e08ca45-9a00-4c6a-ac38-169c7e87d9e4
# MAGIC %md
# MAGIC ## Loading in the data
# MAGIC Below is the command for reading in a csv file into a Spark Dataframe that can be used passed to a model. The dataframe can be displayed using 'display(df)'. Or it can be converted to a Pandas Dataframe and displayed by typeing 'df' into a cell.

# COMMAND ----------

#Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ## Split the dataframe into a test and train dataset
# MAGIC The cell below shows the splitting of data into a training and test dataset. This is a vital step when building  a machine learninging model since a model needs to be tested on data it hasn't seen before. Typically the test dataset if smaller than the training dataset (20%-30%). Depending on the type of problem, will determine the way it is split. Below uses a random split where the data is shuffled around (removes ordering).

# COMMAND ----------

#Fill in here

# COMMAND ----------

# DBTITLE 0,--i18n-733cd880-143d-42c2-9f29-602e48f60efe
# MAGIC %md 
# MAGIC ### Distributed Training of XGBoost Models
# MAGIC To use the distributed version of XGBoost's PySpark estimators, you can specify two additional parameters:
# MAGIC
# MAGIC * **`num_workers`**: The number of workers to distribute over.
# MAGIC * **`use_gpu`**: Enable to utilize GPU based training for faster performance.
# MAGIC
# MAGIC For more information about these parameters and performance considerations, please check this <a href="https://docs.databricks.com/en/machine-learning/train-model/xgboost-spark.html" target="_blank">documentation page.</a>

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 3
# MAGIC Create an XGBoost model and pipeline. Also create another model pipeline to compare against. 

# COMMAND ----------

#Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create predictions for both pipelines
# MAGIC Training below gives predictions for two models. One being the XGBoost model, the other being PySparks GBT model for comparison.

# COMMAND ----------

#Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 4
# MAGIC Train both models and output to dataframes

# COMMAND ----------

#Fill in here

# COMMAND ----------

# DBTITLE 0,--i18n-8d5f8c24-ee0b-476e-a250-95ce2d73dd28
# MAGIC %md
# MAGIC ## Scoring the model
# MAGIC The cell below shows how the use can score the model. A couple of metrics are shown below. More information on scoring metrics will be given in another part of the course. 

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 5
# MAGIC Use evaluation metrics to compare the two models. Print out the results. 

# COMMAND ----------

#Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ## Comparing the model
# MAGIC Here we compare the score with the GBT model

# COMMAND ----------

#Fill in here