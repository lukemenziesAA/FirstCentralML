# Databricks notebook source
# MAGIC %md
# MAGIC <div style="text-align: left; line-height: 0; padding-top: 9px; padding-left:150px">
# MAGIC   <img src="https://static1.squarespace.com/static/5bce4071ab1a620db382773e/t/5d266c78abb6d10001e4013e/1562799225083/appliedazuredatabricks3.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>
# MAGIC
# MAGIC # *HyperOpt*. Presented by <a href="www.advancinganalytics.co.uk">Advancing Analytics</a>

# COMMAND ----------

# MAGIC %md
# MAGIC 💡 In this lesson you will grasp the following concepts:
# MAGIC * How to use HyperOpt for hyperparameter tuning

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 1
# MAGIC Load in a dataset. Pick one to use or use one provided. 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Loading in the data
# MAGIC Below is the command for reading in a csv file into a Pandas Dataframe that can be used passed to a model.

# COMMAND ----------

#Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ## Importing libraries

# COMMAND ----------

from sklearn.model_selection import train_test_split

# COMMAND ----------

# MAGIC %md
# MAGIC ## Splitting dataset into test and train set

# COMMAND ----------

X_train, X_test, y_train, y_test = # Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 2
# MAGIC Import appropriate libraries for HyperOpt and any other ml libraries needed. 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Importing routines for use in HyperOpt

# COMMAND ----------

#Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 3
# MAGIC Create function that accepts parameters to be tuned. You can choose any parameters you like. 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Define the training model
# MAGIC Here we create a function that is used for training. This is customisable to have whatever you like. It takes parameters as arguments that are then logged using MLFlow. It outputs the loss function which can be coded to be whatever the user like. Here it is chosen to be the mean squared error. 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Define the objective function
# MAGIC Here it takes the training function and passes the parameters to it (once formatted) and outputs the loss function so HyperOpt can use it. 

# COMMAND ----------

# Define hyperopt objective function
def train_with_hyperopt(params):

    # Fill in here
    
    return {"loss": loss, "status": STATUS_OK}

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 4
# MAGIC Define the search space needed. 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Define the search space
# MAGIC Here the search space parameters can be defined in the following way:
# MAGIC
# MAGIC -  'uniform' - for real parameters with uniform weighting
# MAGIC -  'quniform' - for integer parameters with uniform weighting
# MAGIC -  'choice' - discrete parameters chosen from a given list
# MAGIC -  'lognormal' - real parameter weighted so the log of the return is normally distributed
# MAGIC This is the grid space that will be searched. 

# COMMAND ----------

# Define search space
space = # Fill in here

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 5
# MAGIC Run HyperOpt and output the best parameters found.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Running HyperOpt
# MAGIC The run ready to be exectued with the command below (fmin). This is where is searches for the best parameter that minimise the loss function. The objective function and grid space are passed as arguments. The 'max_evals' limits the number of iterations over the cluster. The output is a dictionary containing the best parameters from the run. 

# COMMAND ----------

# Run HyperOpt to find optimal hyperparam values
from hyperopt import SparkTrials

# Fill in here

with mlflow.start_run():
    best_params = fmin(
        # Fill in here
    )