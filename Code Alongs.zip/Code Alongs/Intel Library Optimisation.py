# Databricks notebook source
# MAGIC %md
# MAGIC <div style="text-align: left; line-height: 0; padding-top: 9px; padding-left:150px">
# MAGIC   <img src="https://static1.squarespace.com/static/5bce4071ab1a620db382773e/t/5d266c78abb6d10001e4013e/1562799225083/appliedazuredatabricks3.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>
# MAGIC
# MAGIC # *Intel Library Optimisation*. Presented by <a href="www.advancinganalytics.co.uk">Advancing Analytics</a>

# COMMAND ----------

# MAGIC %md
# MAGIC 💡 In this lesson you will grasp the following concepts:
# MAGIC * How to build a linear regression model
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 1
# MAGIC Run the code below to train the model and make note of the training time

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 2
# MAGIC Install the threadpoolctl==3.1.0 and scikit-learn-intelex on the cluster. Restart the cluster

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 3
# MAGIC In the Fill in here line, initiate the scikit-learn-intelex library by importing and executing the patch 'patch_sklearn()'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 4
# MAGIC Re-run the cells below and compare the training time. 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Loading in the data
# MAGIC Below is the command for reading in a csv file into a Spark Dataframe that can be used passed to a model. The dataframe can be displayed using 'display(df)'. Or it can be converted to a Pandas Dataframe and displayed by typeing 'df' into a cell.

# COMMAND ----------

from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, MinMaxScaler
from sklearn.impute import SimpleImputer
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.svm import SVC
from sklearn.metrics import f1_score, make_scorer
from sklearn.pipeline import Pipeline
import pandas as pd

# COMMAND ----------

readPath = "dbfs:/FileStore/tables/credit_card_churn.csv"

drop_cols = [
    "Naive_Bayes_Classifier_Attrition_Flag_Card_Category_Contacts_Count_12_mon_Dependent_count_Education_Level_Months_Inactive_12_mon_1",
    "Naive_Bayes_Classifier_Attrition_Flag_Card_Category_Contacts_Count_12_mon_Dependent_count_Education_Level_Months_Inactive_12_mon_2",
]

df = (
    spark.read.option("header", True)
    .format("csv")
    .option("inferSchema", True)
    .load(readPath)
).toPandas().drop(drop_cols, axis=1)

target_col = "Attrition_Flag"


# COMMAND ----------

string_cols = [col for col, dtype in df.dtypes.items() if dtype == "object"]
string_cols.remove(target_col)
numeric_cols = [
    col for col, dtype in df.dtypes.items() if pd.api.types.is_numeric_dtype(dtype)
]
num_pipe = Pipeline(
    [
        ("imp", SimpleImputer(strategy="constant", fill_value=0)),
        ("scale", MinMaxScaler()),
    ]
)
cat_pipe = Pipeline(
    [
        ("imp", SimpleImputer(strategy="most_frequent")),
        ("enc", OneHotEncoder(drop="first")),
    ]
)
trans = ColumnTransformer(
    [
        ("num", num_pipe, numeric_cols),
        ("cat", cat_pipe, string_cols),
    ]
)
clf = SVC()
model = Pipeline([("trans", trans), ("clf", clf)])
X = df.drop(target_col, axis=1)
y = df[target_col].values.flatten()
scoring = make_scorer(f1_score, pos_label="Attrited Customer")
kfold = StratifiedKFold(n_splits=5)
f1 = cross_val_score(model, X, y, cv=kfold, scoring=scoring).mean()
print(f"The model f1 score: {f1}")